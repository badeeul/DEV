from typing import List, Optional
from datetime import datetime, timezone
from abc import ABC, abstractmethod
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.functions import col, expr, sha2, concat_ws, lit, desc
from pyspark.sql.types import StructType, LongType, StructField

from delta.tables import DeltaTable

from pyspark.sql import functions as F
from pyspark.sql.window import Window

from spark_engine.sparkconf import spark
from spark_engine.common.lakehouse import LakehouseManager
from spark_engine.transform.metadata import Metadata

class LoadStrategy(ABC):

    @abstractmethod
    def transform(self, source_data: DataFrame) -> None:
        raise NotImplementedError
    
    def configure_load(
        self,
        target_lakehouse: LakehouseManager,
        target_schema: str,
        target_table: str,
        elt_id: str,
        run_id: str,
        unknown_record: Optional[bool] = None,
        identity: Optional[bool] = None,
        identity_column_name: Optional[str] = None,
        candidate_keys: Optional[List] = None,
        partition_keys: Optional[List] = None,
        batch_time: Optional[datetime] = None,
    ) -> None:
        """
        Configure columns for transform
        """
        if not batch_time:
            batch_time = datetime.now(timezone.utc).isoformat()
        self.batch_time = batch_time

        self._target_schema = target_schema
        self._target_table = target_table
        self._unknown_record = unknown_record
        self._identity = identity
        self._identity_column_name = identity_column_name
        self._candidate_keys = candidate_keys
        self._partition_keys = partition_keys
        self._elt_id = elt_id
        self._run_id = run_id

        self._target_lakehouse = target_lakehouse
        self._target_exists = self._target_lakehouse.check_if_table_exists(self._target_table, self._target_schema)
        self._target_path = self._target_lakehouse.build_delta_file_path(self._target_table, self._target_schema)

        assert candidate_keys if identity else True, "Key columns must be defined when identity column is enabled."

    def get_table_metrics(self, table_path: str) -> tuple:
        df = DeltaTable.forPath(spark, table_path).history().where(f"timestamp > '{self.batch_time}'")
        df = (
            df.selectExpr(
                "operation",
                "operationMetrics.numTargetRowsInserted",
                "operationMetrics.numTargetRowsUpdated",
                "operationMetrics.numTargetRowsDeleted",
                "operationMetrics.numOutputRows",
                "operationMetrics.numUpdatedRows",
                "operationMetrics.numDeletedRows",
                "operationMetrics.numOutputBytes",
            )
            .orderBy(desc("timestamp"))
        )

        inserts = updates = deletes = output_bytes = 0
        for row in df.collect():
            (
                op,
                tar_inserts,
                tar_updates,
                tar_deletes,
                rec_inserts,
                rec_updates,
                rec_deletes,
                rec_bytes_output,
            ) = row
            if op in {
                "CREATE TABLE AS SELECT",
                "WRITE",
                "CREATE OR REPLACE TABLE",
                "CREATE OR REPLACE TABLE AS SELECT",
            }:
                inserts += int(rec_inserts)
                output_bytes += int(rec_bytes_output)
            elif op == "MERGE":
                inserts += int(tar_inserts)
                updates += int(tar_updates)
                deletes += int(tar_deletes)
            elif op == "UPDATE":
                updates += int(rec_updates)
            elif op == "DELETE":
                deletes += int(rec_deletes)

        return inserts, updates, deletes, output_bytes
    
    @staticmethod
    def add_type_two_metadata(df: DataFrame):
        df = (
                df
                .withColumn("dl_is_current_flag", lit(1).cast("boolean"))
                .withColumn("dl_row_effective_date", expr("to_timestamp('1900-01-01','yyyy-MM-dd')").cast("timestamp"))
                .withColumn("dl_row_expiration_date", expr("to_timestamp('9999-12-31','yyyy-MM-dd')").cast("timestamp"))
            )
        return df

    @staticmethod
    def create_merge_predicate(merge_predicate: list[str]) -> str:
        return " and ".join([f"source.{item} = target.{item}" for item in merge_predicate])
    
    def add_unknown(self, df: DataFrame, type_two_keys: list[str] = None) -> DataFrame:
        unknown_df = spark.createDataFrame(data=spark.sparkContext.emptyRDD(), schema=StructType([]))
        for record_type in [-1,-2]:
            key_desc = "unknown" if record_type == -1 else "not applicable"
            col_list = []

            for col in df.dtypes:
                if not col[0].startswith("dl_"):
                    if col[1] == "string":
                        col_list.append(f"'{key_desc}' as {col[0]}")
                    elif col[1] in ["int", "bigint"]:
                        col_list.append(f"{record_type} as {col[0]}")
                    else:
                        col_list.append(f"null as {col[0]}")

            unknown_df = unknown_df.unionByName(spark.sql("select " + ",".join(col for col in col_list)), allowMissingColumns=True)
            
        metadata = Metadata(
            {
                "meta_column_prefix": "dl_",
                "batch_time": self.batch_time,
                "elt_id": self._elt_id,
                "run_id": self._run_id,
            },
            sorted(unknown_df.columns),
        )
        unknown_df = metadata.add_metadata_columns(unknown_df)
        
        if type_two_keys:
            hash_key = ",".join(c for c in type_two_keys)
            unknown_df = self.add_type_two_metadata(df=unknown_df)
            unknown_df = (
                unknown_df
                .withColumn("merge_key", expr(f"sha2(concat_ws('||', {hash_key}), 256)"))
                .withColumn("dl_row_hash", expr(f"sha2(concat_ws('||', {hash_key}), 256)"))
            )

        df = df.unionByName(unknown_df, allowMissingColumns=True)
            
        return df
    
    def add_identity(self, df: DataFrame) -> DataFrame:
        """
        Strategy-aware surrogate key assignment:
        - TypeTwoLoad (SCD2): ALWAYS assign a brand-new sequential identity
          (new version rows never reuse the expired row's identity).
        - MergeLoad (SCD1) and other strategies: REUSE existing identity
          when the business key already exists in the target table.
        """
        if not self._candidate_keys:
            raise ValueError("candidate_keys must be defined when identity=True")

        # We expect a list of strings
        candidate_keys = self._candidate_keys
        identity_col = self._identity_column_name

        # 1. Deterministic ordering for new key assignment
        if len(candidate_keys) == 1:
            order_col = F.col(candidate_keys[0])
        else:
            order_col = F.concat_ws(
                "||",
                *[F.coalesce(F.col(c).cast("string"), F.lit("")) for c in candidate_keys]
            )

        # 2. Get current max identity from target (0 if table is new/empty)
        if self._target_exists and not isinstance(self, OverwriteLoad):
            target_df = spark.read.format("delta").load(self._target_path)
            max_identity = target_df.select(
                F.coalesce(F.max(identity_col), F.lit(0)).alias("max_id")
            ).collect()[0]["max_id"]
        else:
            max_identity = 0
            target_df = None

        # SCD2 PATH: Always assign brand-new identity to every row
        if isinstance(self, TypeTwoLoad):
            distinct_keys = df.select(*candidate_keys).distinct()
            if distinct_keys.rdd.isEmpty():
                new_assignments = distinct_keys.withColumn(identity_col, F.lit(0).cast("long"))
            else:
                w = Window.orderBy(order_col)
                new_assignments = distinct_keys.withColumn(
                    identity_col,
                    (F.lit(max_identity) + F.row_number().over(w)).cast("long")
                )

            df_without_id = df.drop(identity_col)
            result_df = (
                df_without_id
                .join(new_assignments, on=candidate_keys, how="left")
                .filter(F.col(identity_col).isNotNull())
            )
        # SCD1 (MergeLoad) + other strategies: Reuse existing identity
        else:
            # Existing natural key → identity mapping
            if target_df is not None:
                existing_map = (
                    target_df
                    .select(*[F.col(c) for c in candidate_keys], F.col(identity_col))
                    .distinct()
                )
            else:
                existing_map = None

            # Only keys that are genuinely new
            new_keys_df = df.select(*candidate_keys).distinct()
            if existing_map is not None:
                new_keys_df = new_keys_df.join(
                    existing_map.select(*candidate_keys),
                    on=candidate_keys,
                    how="left_anti"
                )

            # Assign new identities only to new keys
            if new_keys_df.rdd.isEmpty() or new_keys_df.count() == 0:
                new_assignments = None
            else:
                w = Window.orderBy(order_col)
                new_assignments = new_keys_df.withColumn(
                    identity_col,
                    (F.lit(max_identity) + F.row_number().over(w)).cast("long")
                )

            # Full mapping = existing + newly assigned
            if existing_map is not None:
                full_mapping = existing_map
                if new_assignments is not None:
                    full_mapping = full_mapping.unionByName(new_assignments, allowMissingColumns=True)
            else:
                full_mapping = new_assignments

            # Join mapping back to full input DataFrame
            df_without_id = df.drop(identity_col)
            result_df = (
                df_without_id
                .join(full_mapping, on=candidate_keys, how="left")
                .filter(F.col(identity_col).isNotNull())
            )

        # Put identity column first, then original columns (preserving order)
        final_cols = [identity_col] + [c for c in df_without_id.columns if c != identity_col]
        return result_df.select(*final_cols)

    @staticmethod
    def get_upd_col(df: DataFrame, exclusions: list[str]) -> dict:
        upd_col = {}
        for i in df.columns:
            if(i in exclusions):
                continue
            upd_col[i] = "source." + i

        return upd_col

class TypeTwoLoad(LoadStrategy):
    def transform(self, source_data: DataFrame) -> None:
        df = self.add_type_two_metadata(source_data)
        

        if self._target_exists:
            deltaTableDest = DeltaTable.forPath(spark, self._target_path)

            # union incoming records again if they are different from the target (need to expire and create new records)
            df = (
                df
                .withColumn("merge_key", sha2(concat_ws('||', *(col(c).cast("string") for c in self._candidate_keys)), 256))
                
                .unionAll(
                    df.alias("source")
                    .join(deltaTableDest.toDF().alias("target"), expr(self.create_merge_predicate(self._candidate_keys) + " and target.dl_is_current_flag = True and target.dl_row_hash <> source.dl_row_hash"), how="inner")
                    .selectExpr("source.*")
                    .withColumn("merge_key", lit(None))
                    .withColumn("dl_row_effective_date", lit(self.batch_time).cast("timestamp"))
                )
            )

            if self._identity:
                df = self.add_identity(df)
            if self._unknown_record:
                df = self.add_unknown(df=df, type_two_keys=self._candidate_keys)
            upd_col = self.get_upd_col(df=df, exclusions=["merge_key"])
            hash_predicate = ", ".join(f"target.{item}" for item in self._candidate_keys)

            (
                deltaTableDest
                .alias("target")
                .merge(
                    df.alias("source"),
                    f"source.merge_key = sha2(concat_ws('||', {hash_predicate}), 256)"
                )
                .whenMatchedUpdate(
                    "target.dl_row_hash <> source.dl_row_hash and target.dl_is_current_flag = True",
                    set = {
                        "dl_is_current_flag": "False",
                        "dl_row_expiration_date": f"cast('{self.batch_time}' as timestamp)",
                        "dl_row_update_timestamp": f"cast('{self.batch_time}' as timestamp)"
                    }
                )
                .whenNotMatchedInsert(values=upd_col) # use upd_col because it doesn't contain the merge_key column
                .execute()
            )

        else:
            if self._identity:
                df = self.add_identity(df=df)
            if self._unknown_record:
                df = self.add_unknown(df=df, type_two_keys=self._candidate_keys)
                df = df.drop("merge_key")
            self._target_lakehouse.write_delta_table(df, self._target_schema, self._target_table, self._partition_keys, "overwrite")

class MergeLoad(LoadStrategy):
    def transform(self, source_data: DataFrame) -> None:
        df = source_data
        if self._identity:
            df = self.add_identity(df=df)
            
        if self._unknown_record:
            df = self.add_unknown(df=df)
        
        if self._target_exists:
            deltaTableDest = DeltaTable.forPath(spark, self._target_path)
            
            # Exclude columns that are not meant to be updated in the merge
            upd_col = self.get_upd_col(df=df, exclusions=["dl_row_insert_timestamp"])

            (
                deltaTableDest.alias("target")
                .merge(
                    df.alias("source"),
                    self.create_merge_predicate(self._candidate_keys)
                )
                .whenMatchedUpdate("target.dl_row_hash <> source.dl_row_hash", set=upd_col)
                .whenNotMatchedInsertAll()
                .execute()
            )
        
        else:
            self._target_lakehouse.write_delta_table(df, self._target_schema, self._target_table, self._partition_keys, "overwrite")

class OverwriteLoad(LoadStrategy):
    def transform(self, source_data: DataFrame) -> None:
        if self._identity:
            source_data = self.add_identity(df=source_data)
        self._target_lakehouse.write_delta_table(
            source_data,
            self._target_schema,
            self._target_table,
            self._partition_keys,
            "overwrite",
            mergeSchema=True
        ) 

class AppendLoad(LoadStrategy):
    def transform(self, source_data: DataFrame) -> None:
        self._target_lakehouse.write_delta_table(source_data, self._target_schema, self._target_table, self._partition_keys, "append", mergeSchema=True)

class OverwriteByKey(LoadStrategy):
    def transform(self, source_data: DataFrame) -> None:
        if self._identity:
            source_data = self.add_identity(df=source_data)

        if self._target_exists:
            deltaTableDest = DeltaTable.forPath(spark, self._target_path)
            delete_df = source_data.select(*self._candidate_keys).distinct()
            (
                deltaTableDest.alias("target")
                .merge(
                    delete_df.alias("source"),
                    self.create_merge_predicate(self._candidate_keys)
                )
                .whenMatchedDelete()
                .execute()
            )

        self._target_lakehouse.write_delta_table(source_data, self._target_schema, self._target_table, self._partition_keys, "append", mergeSchema=True)


class LoadTypes:
    class LoadStrategies:
        TYPE_TWO_LOAD = TypeTwoLoad
        MERGE_LOAD = MergeLoad
        OVERWRITE_LOAD = OverwriteLoad
        APPEND_LOAD = AppendLoad
        OVERWRITE_BY_KEY_LOAD = OverwriteByKey

    @classmethod
    def get_load_type(cls, load_type: str):
        load_type = load_type.upper()
        if not load_type.endswith("_LOAD"):
            load_type += "_LOAD"

        load_strategy = getattr(cls.LoadStrategies, load_type)

        return load_strategy()