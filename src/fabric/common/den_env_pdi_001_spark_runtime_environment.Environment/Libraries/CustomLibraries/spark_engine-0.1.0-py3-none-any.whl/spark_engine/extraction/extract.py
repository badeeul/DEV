import json

from spark_engine.extraction.source_type import SourceType

class Extract:
    """
    Extract class to get the source class for extracting data.
    Requires the full dataset config to be provided.
    Returns the source extract class as determined by the 
    sourceSystemName.
    """
        
    @classmethod
    def source(
        cls,
        config
    ):
        config = (
            config
            if isinstance(config, dict)
            else json.loads(config)
        )
        source_type = config["sourceSystemProperties"]["sourceSystemName"]
        try:
            source = SourceType.get_source_type(source_type)
            source.config = config
            return source
        except AttributeError as e:
            raise ValueError(f"Source type: {source_type} is not supported.") from e
    