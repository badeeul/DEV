from spark_engine.sparkconf import spark
from spark_engine.ingestion.ingest import Ingest
from spark_engine.extraction.extract import Extract
from spark_engine.transform.transform import Transform


class SparkEngine:
    """
    The entry point to the spark ELT.
    """

    @classmethod
    def ingest(cls, ingest_config: str) -> Ingest:
        """
        Returns a class that can be used to ingest data into the Delta lake.

        Parameters
        ----------
        :ingest_config: str `The metadata configuration for the table to be loaded.

        Returns
        -------
        :class:`Ingest`
        """
        return Ingest(ingest_config)
    
    @classmethod
    def transform(cls, transform_config: str) -> Transform:
        """
        Returns a class that can be used to transform data in the Delta lake.

        Parameters
        ----------
        :transform_config: str `The metadata configuration for the table to be loaded.

        Returns
        -------
        :class:`Transform`
        """
        return Transform(transform_config)
