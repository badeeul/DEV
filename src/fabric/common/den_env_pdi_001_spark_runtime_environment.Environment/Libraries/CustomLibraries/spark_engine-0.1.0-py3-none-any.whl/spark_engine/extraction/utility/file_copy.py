from abc import ABC, abstractmethod
import fsspec
import json
import csv

class FileCopy(ABC):
    def __init__(self):
        storage_options = {
            "account_name": "onelake",
            "account_host": "onelake.dfs.fabric.microsoft.com",
        }
        self.onelake_fs = fsspec.filesystem("abfss", **storage_options)

    @abstractmethod
    def copy_data(
            self,
            data: dict,
            file_path: str,
            file_name: str
    ):
        raise NotImplementedError
    
    def get_name(self):
        return self.__class__.__name__


class JsonCopy(FileCopy):
    def copy_data(
            self,
            data: dict,
            file_path: str,
            file_name: str
    ):
        """
        Copy data in dict format to lakehouse as a JSON file.
        """
        if not type(data) == dict:
            raise ValueError(f"Source data type ({type(data).__name__}) is not a dict.")
        
        target_file = f"{file_path}/{file_name}"
        if not target_file[-5:] == ".json":
            target_file += ".json"
        with self.onelake_fs.open(target_file, "w") as json_file:
            json.dump(data, json_file, indent=4)
            
        print(f"File generated at: {target_file}")


class CsvCopy(FileCopy):
    # copy_data method may need to be enhanced as more use cases are discovered.
    # The method currently only supports list of dicts.
    def copy_data(
            self,
            data: list,
            file_path: str,
            file_name: str
    ):
        """
        Copy data in list format to lakehouse as a CSV file.
        """
        if not type(data) == list:
            raise ValueError(f"Source data type ({type(data).__name__}) is not a list.")
        
        target_file = f"{file_path}/{file_name}"
        if not target_file[-4:] == ".csv":
            target_file += ".csv"

        with self.onelake_fs.open(target_file, "w", newline="") as csv_file:
            field_names = []
            for row in data:
                for field in row:
                    field_names.append(field)

            field_names = [field for field in set(field_names)]
            writer = csv.DictWriter(
                csv_file,
                fieldnames=field_names,
                delimiter=',',
                quotechar='"',
                escapechar='\\'
            )
            writer.writeheader()
            writer.writerows(data)
            
        print(f"File generated at: {target_file}")


class FileStrategy:
    class FileTypes:
        JSON = JsonCopy
        CSV = CsvCopy

    @classmethod
    def get_file_strategy(cls, file_strategy: str):
        file_strategy = file_strategy.upper()
        try:
            file_type = getattr(cls.FileTypes, file_strategy)
        except Exception as e:
            raise ValueError(f"File copy type: {file_strategy} is not supported.") from e
        return file_type()