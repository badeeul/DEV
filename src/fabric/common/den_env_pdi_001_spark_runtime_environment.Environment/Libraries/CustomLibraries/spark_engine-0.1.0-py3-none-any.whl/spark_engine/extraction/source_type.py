# from spark_engine.extraction.extract import Extract
from spark_engine.extraction.type import (
    NWSAPI
)

class SourceType:
    """
    Supported Sources for extracting data. New sources
    should be added here as they are developed.
    """

    NWS_API = NWSAPI

    @classmethod
    def get_source_type(cls, name: str):
        source_type = getattr(cls, name.upper())
        return source_type()