import json
from typing import Optional
from dataclasses import asdict, dataclass, field
from datetime import datetime, date


@dataclass
class ExtractionMetrics:
    """
    Metrics collected during extraction.
    """

    extractSuccess: bool = False
    copySuccess: bool = False
    eltId: str = None
    runId: str = None
    extractStartTime: str = None
    extractEndTime: str = None
    extractDuration: int = 0
    copyStartTime: str = None
    copyEndTime: str = None
    copyDuration: int = 0
    copyStrategy: str = None
    copyLakehouse: dict = None
    error: Optional[str] = None
    outputBytes: int = 0

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), default=str)
    