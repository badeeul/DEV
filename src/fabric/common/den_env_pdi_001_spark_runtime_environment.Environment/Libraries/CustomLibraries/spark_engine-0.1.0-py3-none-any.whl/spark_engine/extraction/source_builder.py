from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Dict
import sys

from spark_engine.common.lakehouse import LakehouseManager
from spark_engine.extraction.metrics import ExtractionMetrics

class SourceBuilder(ABC):
    """
    Source builder class contains the generic methods used for
    extracting and saving data to a lakehouse. It uses the
    dataset config where the sourceSystemProperties and
    rawProperties are needed.
    """

    METRICS: ExtractionMetrics

    def __init__(self):
        self.METRICS = ExtractionMetrics()
        self.elt_id = "0"
        self.run_id = "0"

    @property
    def config(self):
        return self._config
    
    @config.setter
    def config(self, config: Dict):
        self._config = config
      
    @abstractmethod
    def extract(self):
        """Abstract method to extract source data"""
        raise NotImplementedError
    
    @abstractmethod
    def validate_config(self):
        """Abstract method to validate config"""
        raise NotImplementedError
    
    def configure_source(self, config: Dict):
        self.elt_id = config.get("elt_id", "0")
        self.run_id = config.get("run_id", "0")
        self.watermark_start = config.get("watermark_start")
        self.watermark_end = config.get("watermark_end")
        return self
    
    def get_raw_path(self):
        self.lakehouse_name = self.config["rawProperties"]["lakehouseName"]
        self.lakehouse_dir = self.config["rawProperties"]["directoryName"]
        self.dataset_name = self.config["datasetName"]
        self.METRICS.copyLakehouse = {
            "Lakehouse": self.lakehouse_name,
            "LakehouseDir": self.lakehouse_dir,
            "DatasetName": self.dataset_name
        }
        
        # return r"C:\Users\TleeHIT\Downloads\nws_extract" # uncomment and update to test locally
        raw_lakehouse = LakehouseManager(self.lakehouse_name)
        return f"{raw_lakehouse.lakehouse_path}/Files/{self.lakehouse_dir}/{self.dataset_name}/{self.run_id}"
    
    def get_data(self) -> None:
        """
        Generic method to get data from the defined source.
        The extract method is where the source specific logic
        will occur.

        Config validation will also happen here and must be defined
        in the source class.
        """
        extractStartTime = datetime.now(timezone.utc)
        
        self.validate_config(self.config["sourceSystemProperties"])
        self.source_data = self.extract()

        extractEndTime = datetime.now(timezone.utc)

        self.METRICS.extractSuccess = True
        self.METRICS.outputBytes = sys.getsizeof(self.source_data)
        self.METRICS.extractStartTime = extractStartTime.isoformat()
        self.METRICS.extractEndTime = extractEndTime.isoformat()
        self.METRICS.extractDuration = (extractEndTime - extractStartTime).total_seconds()
        return self

    def copy_data(self) -> None:
        """
        Generic method to copy the extracted data to the defined
        location. The file copy strategy must be defined in the
        source class as self.file_strategy and be one of the
        allowed file copy types in the FileCopy class.

        The file copy strategy should align with the data being
        returned from the extract method.

        """
        copyStartTime = datetime.now(timezone.utc)

        raw_path = self.get_raw_path()
        self.file_strategy.copy_data(
            self.source_data,
            raw_path,
            self.dataset_name
        )

        copyEndTime = datetime.now(timezone.utc)

        self.METRICS.copySuccess = True
        self.METRICS.copyStrategy = self.file_strategy.get_name()
        self.METRICS.copyStartTime = copyStartTime.isoformat()
        self.METRICS.copyEndTime = copyEndTime.isoformat()
        self.METRICS.copyDuration = (copyEndTime - copyStartTime).total_seconds()
        return self
    
    def metrics(self, frmt: str = "json"):
        """
        Get the metrics that were generated during the transform process in json or dict format.
        """
        if frmt == "json":
            return self.METRICS.to_json()
        if frmt == "dict":
            return self.METRICS.to_dict()

