import pandas as pd
import os
import warnings
import notebookutils
from typing import Dict, List, Optional
from abc import ABC, abstractmethod
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.functions import first, lit, col
from functools import reduce

from spark_engine.sparkconf import spark
from spark_engine.common.string_handlers import strip_string

warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

class FileStrategy(ABC):
    source_options: Dict

    def __init__(
        self,
        source_options: Optional[Dict] = None,
        custom_file_options: Optional[Dict] = None,
    ) -> None:
        self.source_options = source_options if source_options else {}
        self.custom_file_options = custom_file_options if custom_file_options else {}

    @abstractmethod
    def read_file(self, file_path: str) -> DataFrame:
        pass

    def get_dir_content(self, ls_path):
        for dir_path in notebookutils.fs.ls(ls_path):
            if dir_path.isFile:
                yield dir_path
            elif dir_path.isDir and ls_path != dir_path.path:
                yield from self.get_dir_content(dir_path.path)


class CsvFile(FileStrategy):
    def read_file(self, file_path: str):
        return (
            spark.read.format("csv")
            .option("recursiveFileLookup", "true")
            .options(**self.source_options)
            .load(file_path)
        )


class ParquetFile(FileStrategy):
    def read_file(self, file_path: str):
        return (
            spark.read.format("parquet")
            .option("recursiveFileLookup", "true")
            .options(**self.source_options)
            .load(file_path)
        )


class ExcelFile(FileStrategy):
    """
    Read an Excel file using the file options config. If there are multiple sheet
    configured then they will be cross joined and returned as a dataframe.
    """

    def read_file(self, file_path: str):
        file_list = list(self.get_dir_content(file_path)) # recursive list of files
        df_list = []

        for file in file_list:
            if file.isDir:
                continue

            file_path, file_extension = os.path.splitext(file.path)
            if file_extension not in [".xlsx",".xls",".xlsb",".xlsm"]:
                continue

            joined_df = None

            if isinstance(self.custom_file_options, dict):
                self.custom_file_options = [self.custom_file_options]

            for config in self.custom_file_options:
                excel_sheet = config["SheetName"]
                skip_rows = config["SkipRows"]
                column_list = config.get("Columns")
                sql_filter = config.get("Filter")
                pivot = config.get("Pivot")

                if column_list:
                    pd_df = pd.read_excel(
                        io=file.path,
                        sheet_name=excel_sheet,
                        skiprows=skip_rows,
                        header=0,
                        usecols=column_list,
                        dtype=str,
                        keep_default_na=False,
                        na_values="",
                    ).dropna(how="all")
                else:
                    pd_df = pd.read_excel(
                        io=file.path,
                        sheet_name=excel_sheet,
                        skiprows=skip_rows,
                        header=0,
                        dtype=str,
                        keep_default_na=False,
                        na_values="",
                    ).dropna(how="all")

                df = spark.createDataFrame(pd_df)

                if sql_filter:
                    df = df.where(sql_filter)

                if pivot:
                    df = (
                        df.groupBy().pivot(pivot["Columns"]).agg(first(pivot["Values"]))
                    )

                if joined_df:
                    joined_df = joined_df.crossJoin(df)
                else:
                    joined_df = df

                joined_df = (
                    joined_df
                    .withColumn("dl_sourcefilepath", lit(file.path))
                    .withColumn("dl_sourcefilename", lit(file.name))
                ) 

            df_list.append(joined_df)

        df = reduce(DataFrame.unionAll, df_list)
        return df


class FileHandler:
    file_handler: FileStrategy

    def __init__(
        self,
        file_format: str,
        source_options: Optional[Dict] = None,
        custom_file_options: Optional[Dict] = None,
    ):
        self.set_file_handler(file_format, source_options, custom_file_options)

    def set_file_handler(
        self,
        file_format: str,
        source_options: Optional[Dict] = None,
        custom_file_options: Optional[Dict] = None,
    ) -> None:
        if file_format == "csv":
            self.file_handler = CsvFile(source_options, custom_file_options)
        elif file_format == "parquet":
            self.file_handler = ParquetFile(source_options, custom_file_options)
        elif file_format == "excel":
            self.file_handler = ExcelFile(source_options, custom_file_options)
        else:
            raise NotImplementedError(f"File format '{file_format}' is not supported.")

    def read_file(self, file_path: str) -> DataFrame:
        df = self.file_handler.read_file(file_path)

        # empty source columns default to void data type so need to change to string
        df = df.withColumns(
            {
                col_name: col(f"`{col_name}`").cast("string")
                for col_name, col_type in df.dtypes
                if col_type == "void"
            }
        )

        for col_name in df.columns:
            df = df.withColumnRenamed(col_name, strip_string(col_name, "", True))
        return df
