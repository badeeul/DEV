import requests
import json

from spark_engine.extraction.source_builder import SourceBuilder
from spark_engine.api_client.base_api import BaseAPI
from spark_engine.extraction.utility.file_copy import CsvCopy

class NWSAPI(SourceBuilder, BaseAPI):

    def __init__(self):
        # set file copy strategy
        self.file_strategy = CsvCopy()
        SourceBuilder.__init__(self)
        BaseAPI.__init__(
            self,
            base_url="https://api.weather.gov",
            user_agent=None,
        )

    def fetch_data(self, *args, **kwargs):
        return self._make_request(
            endpoint=kwargs["endpoint"],
        )

    def validate_config(self, config: dict):
        # try to get required values from config
        try:
            self.lat = config["latitude"]
            self.long = config["longitude"]
        except Exception as e:
            raise ValueError(f"A required config value is missing: {e}")

    def build_forecast_url(self) -> str:
        
        point_url = f"points/{self.lat},{self.long}"
        response_json = self.fetch_data(endpoint=point_url)

        gridId = response_json["properties"]["gridId"]
        gridX = response_json["properties"]["gridX"]
        gridY = response_json["properties"]["gridY"]
        self.forecast_url = f"gridpoints/{gridId}/{gridX},{gridY}/forecast"

    def extract(self):
        # return the value that matches what is expected by the FileCopy strategy
        # new FileCopy strategy may be needed depending on how data is returned
        self.build_forecast_url()
        response_json = self.fetch_data(endpoint=self.forecast_url)
        period_data = response_json["properties"]["periods"]

        return period_data
