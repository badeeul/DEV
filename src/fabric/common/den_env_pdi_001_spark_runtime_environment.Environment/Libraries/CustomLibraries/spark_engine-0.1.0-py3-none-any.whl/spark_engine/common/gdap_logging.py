import logging.config
import sys

class GDAPLogging:
  """
    Creates GDAP logger that sends messages to stdout.
  """
  def __init__(self, logger_name: str, logger_level: int = 10, root_log_level: int = 10, logging_format_spec: str = '%(levelname)s: %(asctime)s: %(lineno)d: %(module)s: %(funcName)s: %(message)s' ) -> None:
     self.logger_name = logger_name
     self.logger_level = logger_level
     self.root_log_level = root_log_level
     self.logging_format_spec = logging_format_spec
     self.__logging_levels_dict = {
           0 : "NOTSET"
           , 10 : "DEBUG"
           , 20 : "INFO"
           , 30 : "WARNING"
           , 40 : "ERROR"
           , 50 : "CRITICAL"
      }
     

  @property
  def logger_level_label(self):
      return self.__logging_levels_dict.get(self.logger_level)
  
  @property
  def root_logger_level_label(self):
      return self.__logging_levels_dict.get(self.root_log_level)
  
  def get_gdap_logger(self) -> logging.Logger:
      """
      Returns GDPA Logger with a specified name logger_name and logging level
      """
      logging_config = """{
      'version': 1
      , 'disable_existing_loggers': False
      , 'formatters': { 
      'default_formatter': { """

      logging_config += f"""
            'format': f'{self.logging_format_spec}'
            """
      logging_config += """
            },
      }
      , 'handlers': { 
      'stream_handler': { 
      """

      logging_config += f"'level': '{self.logger_level_label}'"

      logging_config += """
                  , 'formatter': 'default_formatter'
                  , 'class': 'logging.StreamHandler'
                  , 'stream': 'ext://sys.stdout'
                  }
      }
      , 'loggers': { 
      """

      logging_config += f"'{self.logger_name}': "

      logging_config += """ {
                  'handlers': ['stream_handler'],
      """

      logging_config += f"'level': '{self.root_logger_level_label}',"

      logging_config += """'propagate': True
                        }
                  } 
      }"""

      logging_config_dict  = eval(logging_config)
      logging.config.dictConfig(logging_config_dict)
      gdap_logger = logging.getLogger(self.logger_name)

      return gdap_logger


