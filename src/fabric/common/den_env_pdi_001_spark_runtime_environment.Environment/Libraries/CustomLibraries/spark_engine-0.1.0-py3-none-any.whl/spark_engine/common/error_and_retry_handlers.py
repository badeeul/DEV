from typing import Union, Tuple, Type
from spark_engine.common.gdap_logging import GDAPLogging

from delta.exceptions import (
    DeltaConcurrentModificationException
    , ConcurrentWriteException
    , MetadataChangedException
    , ProtocolChangedException
    , ConcurrentAppendException
    , ConcurrentDeleteReadException
    , ConcurrentDeleteDeleteException
    , ConcurrentTransactionException
    )

from tenacity import (
    retry
    , stop_after_attempt
    , stop_after_delay
    , wait_fixed
    , wait_exponential
    , retry_if_exception_type
    , before_sleep_log
    )

def retry_on_exceptions(exceptions: Union[Tuple[Exception], Tuple[Type[Exception]]] = (Exception, )):
    """
    Retry decorator for handling generic and delta-spark exceptions. 
    """
    return retry(
            retry = ( retry_if_exception_type((
                        Exception
                        , DeltaConcurrentModificationException
                        , ConcurrentWriteException
                        , MetadataChangedException
                        , ProtocolChangedException
                        , ConcurrentAppendException
                        , ConcurrentDeleteReadException
                        , ConcurrentDeleteDeleteException
                        , ConcurrentTransactionException
                    ))
                    )
            , stop = ( stop_after_attempt(4) | stop_after_delay(30) ) # First execution followed by 3 retries
            , wait = wait_fixed(1) + wait_exponential(multiplier=1, min=2, max=2) # inital_delay_seconds = 1, linear_delay = 2 secondsbetween each retry
            , reraise = True 
            # ,  before_sleep = before_sleep_log(logger, logging.INFO)
        )    

@retry_on_exceptions((
                        Exception
                        , DeltaConcurrentModificationException
                        , ConcurrentWriteException
                        , MetadataChangedException
                        , ProtocolChangedException
                        , ConcurrentAppendException
                        , ConcurrentDeleteReadException
                        , ConcurrentDeleteDeleteException
                        , ConcurrentTransactionException
                    ))
def delta_operations_handler(operation):
    """
    Performs a spark operation and retries the same operation incase of an error. Retry details are given below:
    Retry:
        Retry exceptions: Either below exception types or an object of below exception types.
                                Exception
                                , DeltaConcurrentModificationException
                                , ConcurrentWriteException
                                , MetadataChangedException
                                , ProtocolChangedException
                                , ConcurrentAppendException
                                , ConcurrentDeleteReadException
                                , ConcurrentDeleteDeleteException
                                , ConcurrentTransactionException    
        Attempts - 3
        Max duration - 30 seconds
        Initial delay - 1 second
        Delays between retries - 2 seconds
    """
    init_retry_logger = GDAPLogging(logger_name= 'Retry Logger'
                        , logger_level = 10
                        , root_log_level = 10
                        , logging_format_spec='%(levelname)s: %(message)s'
                    )
    retry_logger = init_retry_logger.get_gdap_logger()    
    retry_logger.info('Executing operation leveraging retry.')
    operation()
