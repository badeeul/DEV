from typing import Dict, List, Optional
from datetime import datetime, timezone
from pyspark.sql.functions import lit, concat_ws, sha2, col
from pyspark.sql.dataframe import DataFrame, Column


class Metadata:
    meta_column_prefix: str
    batch_time: datetime

    def __init__(self, config: Dict, columns: List[str]) -> None:
        self.meta_column_prefix = config.get("meta_column_prefix", "dl_")
        self.batch_time = config.get("batch_time", datetime.now(timezone.utc))
        self.elt_id = config.get("elt_id", "0")
        self.run_id = config.get("run_id", "0")
        self.columns = columns

        self.metadata_columns = self.generate_metadata()

    def generate_metadata(self) -> Dict[str, Column]:
        return {
            f"{self.meta_column_prefix}row_hash": sha2(concat_ws('||', *(col(c).cast("string") for c in self.columns)), 256),
            f"{self.meta_column_prefix}row_insert_timestamp": lit(self.batch_time).cast("timestamp"),
            f"{self.meta_column_prefix}row_update_timestamp": lit(self.batch_time).cast("timestamp"),
            f"{self.meta_column_prefix}row_insert_agent": lit("ELT"),
            f"{self.meta_column_prefix}eltid": lit(self.elt_id).cast("string"),
            f"{self.meta_column_prefix}runid": lit(self.run_id).cast("string"),
        }

    def get_metadata_column_names(self) -> List[str]:
        return list(self.metadata_columns.keys())

    def add_metadata_columns(
        self, df: DataFrame, metadata_columns: Optional[List[str]] = None
    ) -> DataFrame:
        if metadata_columns is None:
            metadata_columns = self.get_metadata_column_names()

        return df.withColumns(
            {
                column: self.metadata_columns[column]
                for column in metadata_columns
                if column not in df.columns
            }
        )
