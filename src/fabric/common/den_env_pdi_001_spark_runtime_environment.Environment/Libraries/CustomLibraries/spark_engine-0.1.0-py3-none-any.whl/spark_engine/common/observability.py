from typing import List
from pyspark.sql import SparkSession
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.functions import current_timestamp, lit, expr, col, to_json
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, IntegerType, LongType, DoubleType, BooleanType, ArrayType
from delta.tables import DeltaTable
import datetime

from spark_engine.common.gdap_logging import GDAPLogging
from spark_engine.common.error_and_retry_handlers import delta_operations_handler
from spark_engine.common.lakehouse import LakehouseManager, SchemaManager
from spark_engine.sparkconf import spark

class GDAPObservability:
    def __init__(self, spark: SparkSession
                 , lakehouse: str = 'den_lhw_pdi_001_observability', schema: str = 'audit'
                 , elt_log_table_name = 'elt_log'
                 , elt_zone_log_table_name = 'elt_zone_log'
                 , source_ingestion_log_table_name = 'source_ingestion_log'
                 , logger_name='GDAPObservability', logger_level=10, root_log_level=10
                 , quarantine_log_table_name = "quarantine_log"
                 ):
        self.spark = spark
        self.logger_name = logger_name
        self.logger_level = logger_level
        self.root_log_level = root_log_level
        self.logger = self._setup_logger()
        self.lakehouse = lakehouse
        self.schema = schema
        self.lakehouse_manager = LakehouseManager(lakehouse_name=self.lakehouse)
        self.elt_log_table_name = elt_log_table_name
        self.elt_zone_log_table_name = elt_zone_log_table_name
        self.source_ingestion_log_table_name = source_ingestion_log_table_name
        self.elt_log_table_path = self.lakehouse_manager.build_delta_file_path(self.elt_log_table_name, self.schema)
        self.elt_zone_log_table_path = self.lakehouse_manager.build_delta_file_path(self.elt_zone_log_table_name, self.schema)
        self.source_ingestion_log_table_path = self.lakehouse_manager.build_delta_file_path(self.source_ingestion_log_table_name, self.schema)
        self.quarantine_log_table_name = quarantine_log_table_name

    def _setup_logger(self):
        gdap_logger = GDAPLogging(logger_name=self.logger_name, logger_level=self.logger_level, root_log_level=self.root_log_level)
        return gdap_logger.get_gdap_logger()
    
    def create_observability_table(self, observability_table: str, table_ddl: str):
        delta_operations_handler(lambda: self.spark.sql(table_ddl))
        self.logger.info(f"Created table if not exists: {observability_table}")

    def execute_spark_query(self, spark_sql_query: str):
        delta_operations_handler(lambda: self.spark.sql(spark_sql_query))
        self.logger.info(f"Executing spark sql: {spark_sql_query}")        

    def _create_table(self, table_name: str, lakehouse_schema: str, table_schema: StructType, partition_by: List[str]):
        table_path = self.lakehouse_manager.build_delta_file_path(table_name, lakehouse_schema)

        emptyRDD = self.spark.sparkContext.emptyRDD()
        empty_df = self.spark.createDataFrame(emptyRDD, table_schema)

        if not (self.lakehouse_manager.check_if_table_exists(table_name, lakehouse_schema)):
            delta_operations_handler(lambda: (empty_df.write
                                              .format("delta")
                                              .partitionBy(*partition_by)
                                              .save(table_path)
                                              )
                                     )
            self.logger.info(f"Created table : {table_name}")

        elif sorted(empty_df.dtypes) != sorted(self.lakehouse_manager.get_table_dtypes(table_name,lakehouse_schema)):
            self.lakehouse_manager.write_delta_table(empty_df,lakehouse_schema,table_name,partition_by,"append",**{"mergeSchema":"true"})
            self.logger.info(f"Updated table schema : {table_name}")

        else:
            self.logger.info(f"Table exists : {table_name}")

    def create_observability_tables(self):
        elt_log = {
            "name": self.elt_log_table_name,
            "lakehouse_schema": self.schema,
            "table_schema": StructType([
                StructField('master_run_id', StringType())
                , StructField('elt_start_date_time', TimestampType())
                , StructField('elt_end_date_time', TimestampType())
                , StructField('log_date_time', TimestampType())
                , StructField('updated_date_time', TimestampType())
                , StructField('product_name', StringType())
                , StructField('feed_name', StringType())
                , StructField('status', StringType())
                , StructField('orchestration_tool', StringType())
                , StructField('data_platform_version', StringType())
            ])
            ,"partition_by": ["product_name", "feed_name"]
        }

        elt_zone_log = {
            "name": self.elt_zone_log_table_name,
            "lakehouse_schema": self.schema,
            "table_schema": StructType([
                StructField('run_id', StringType())
                , StructField('elt_id', StringType())
                , StructField('product_name', StringType())
                , StructField('feed_name', StringType())
                , StructField('zone', StringType())
                , StructField('stage', StringType())
                , StructField('zone_start_date_time', TimestampType())
                , StructField('zone_end_date_time', TimestampType())
                , StructField('zone_status', StringType())
                , StructField('total_data_size', LongType())
                , StructField('total_models_shared', IntegerType())
                , StructField('total_retry_count', IntegerType())
                , StructField('total_error_count', IntegerType())
                , StructField('invocation_id', StringType())
            ])
            ,"partition_by": ["product_name", "feed_name", "zone", "stage"]
        }

        source_ingestion_log = {
            "name": self.source_ingestion_log_table_name,
            "lakehouse_schema": self.schema,
            "table_schema": StructType([
                StructField('run_id', StringType())
                , StructField('elt_id', StringType())
                , StructField('product_name', StringType())
                , StructField('feed_name', StringType())
                , StructField('source_system', StringType())
                , StructField('dataset_name', StringType())
                , StructField('metadata', StringType())
                , StructField('start_date_time', TimestampType())
                , StructField('end_date_time', TimestampType())
                , StructField('data_read', LongType())
                , StructField('data_written', LongType())
                , StructField('files_read', IntegerType())
                , StructField('files_written', IntegerType())
                , StructField('status', StringType())
                , StructField('throughput', DoubleType())
                , StructField('copy_duration', IntegerType())
                , StructField('inserted_by', StringType())
                , StructField('modified_by', StringType())
                , StructField('zone', StringType())
                , StructField('source_file_path', StringType())
            ])
            ,"partition_by": ["product_name", "feed_name", "source_system", "dataset_name"]
        }

        quarantine_log = {
            "name": self.quarantine_log_table_name,
            "lakehouse_schema": self.schema,
            "table_schema": StructType([
                StructField('source_system', StringType())
                , StructField('dataset_name', StringType())
                , StructField('elt_id', StringType())
                , StructField('run_id', StringType())
                , StructField('total_rows', IntegerType())
                , StructField('quarantine_type', StringType())
                , StructField('log_datetime', TimestampType())
                , StructField('primary_key_list', StringType())
                , StructField('is_notification_enabled', BooleanType())
                , StructField('notification_datetime', TimestampType())
            ])
            ,"partition_by": ["source_system", "dataset_name"]
        }

        dim_dq_rule_master = {
            "name": "dim_dq_rule_master",
            "lakehouse_schema": "data_quality",
            "table_schema": StructType([
                StructField('dq_rule_master_key', IntegerType())
                , StructField('dq_rule_id', StringType())
                , StructField('data_product_name', StringType())
                , StructField('sub_domain_name', StringType())
                , StructField('dq_rule_description', StringType())
                , StructField('dq_rule_constraint', StringType())
                , StructField('dq_rule_dimension', StringType())
                , StructField('dq_screen_type', StringType())
                , StructField('dq_rule_applicable_lakehouse', StringType())
                , StructField('dq_rule_applicable_schema', StringType())
                , StructField('dq_rule_applicable_object', StringType())
                , StructField('dq_rule_applicable_attribute', StringType())
                , StructField('dq_rule_failure_action', StringType())
                , StructField('dq_rule_severity_score', DoubleType())
                , StructField('is_current_flag', BooleanType())
                , StructField('row_effective_date', TimestampType())
                , StructField('row_expiration_date', TimestampType())
            ])
            ,"partition_by": []
        }

        fact_dq_error_event = {
            "name": "fact_dq_error_event",
            "lakehouse_schema": "data_quality",
            "table_schema": StructType([
                StructField('dq_error_event_key', StringType())
                , StructField('dq_error_event_date_key', IntegerType())
                , StructField('dq_rule_master_key', IntegerType())
                , StructField('dp_processing_batch_key', StringType())
                , StructField('time_of_day', StringType())
                , StructField('severity_score', DoubleType())
                , StructField('error_event_timestamp', TimestampType())
            ])
            ,"partition_by": []
        }

        fact_dq_error_event_detail = {
            "name": "fact_dq_error_event_detail",
            "lakehouse_schema": "data_quality",
            "table_schema": StructType([
                StructField('dq_error_event_detail_key', StringType())
                , StructField('dq_error_event_key', StringType())
                , StructField('dq_rule_master_key', IntegerType())
                , StructField('time_of_day', StringType())
                , StructField('tested_record_identifier', ArrayType(StringType()))
                , StructField('tested_record_identifier_delimited', StringType())
                , StructField('error_event_timestamp', TimestampType())
            ])
            ,"partition_by": []
        }

        # empty table for use by the Power BI DQ reporting. This empty table allow direct query a place to put measures.
        dim_dq_metrics = {
            "name": "dim_dq_metrics",
            "lakehouse_schema": "data_quality",
            "table_schema": StructType([
                StructField('dim_dq_metrics', StringType())
            ])
            ,"partition_by": []
        }

        for table in [
            elt_log
            ,elt_zone_log
            ,source_ingestion_log
            ,quarantine_log
            ,dim_dq_rule_master
            ,fact_dq_error_event
            ,fact_dq_error_event_detail
            ,dim_dq_metrics
        ]:
            self._create_table(table["name"], table["lakehouse_schema"], table["table_schema"], table["partition_by"])

        # create the dim_dq_date table required only for the DQ Power BI report.
        self._create_dim_dq_date()

        return self
    
    def _create_dim_dq_date(self):
        """
        Create the dim_dq_date table required by DQ Power BI reporting.
        """
        lakehouse_schema = "data_quality"
        table_name = "dim_dq_date"
        dim_dq_date_df = spark.sql(
            """
            with init as 
            (
                SELECT sequence(to_date('2025-01-01'), to_date('2035-12-31'), interval 1 day) as date
            )
            ,exploded_date as
            (
                select 
                explode(date) as `date`
                from init
            )
            select 
                date,
                cast(date_format(date, 'yyyyMMdd') as int) as DateKey,
                date_format(date, 'EEEE') DayOfWeekName,
                date_format(date, 'MMM') MonthShort,
                date_format(date, 'yyyy-MM') YearMonthName,
                date_format(date, 'MMM yyyy') MonthYearName,
                year(date) Year,
                day(date) DayOfMonth,
                month(date) Month
            from exploded_date
            """
        )
        if not (self.lakehouse_manager.check_if_table_exists(table_name, lakehouse_schema)):
            self.lakehouse_manager.write_delta_table(dim_dq_date_df,lakehouse_schema,table_name,None,"overwrite")
            self.logger.info(f"Created table : {table_name}")
        elif sorted(dim_dq_date_df.dtypes) != sorted(self.lakehouse_manager.get_table_dtypes(table_name,lakehouse_schema)):
            self.lakehouse_manager.write_delta_table(dim_dq_date_df,lakehouse_schema,table_name,None,"overwrite",**{"overwriteSchema":"true"})
            self.logger.info(f"Updated table schema : {table_name}")
        else:
            self.logger.info(f"Table exists : {table_name}")

        
    def initialize_elt_log(self, master_run_id: str, product_name: str, feed_name: str
                                , elt_start_date_time:str
                                , table: str = 'elt_log'):
        
        data = [(master_run_id, product_name, feed_name, elt_start_date_time)]
        columns = ["master_run_id", "product_name", "feed_name", "elt_start_date_time"]
        input_df = self.spark.createDataFrame(data, columns)
        input_df = (input_df
                        .withColumn("status", lit('Running'))
                        .withColumn("log_date_time", current_timestamp())
                        .withColumn("orchestration_tool", lit('data pipeline'))
                        .withColumn("data_platform_version", lit('1.0.0'))
                        .withColumn("elt_start_date_time", col("elt_start_date_time").cast(TimestampType()))
                    )


        elt_log_delta_table = DeltaTable.forPath(self.spark,self.elt_log_table_path)
        elt_log_delta_table.alias("tgt").merge(
            source = input_df.alias("src"),
            condition = "src.master_run_id = tgt.master_run_id"
            ).whenNotMatchedInsert(values =
                    {
                        "master_run_id": "src.master_run_id"
                        , "product_name" : "src.product_name"
                        , "feed_name" : "src.feed_name"
                        , "elt_start_date_time" : "src.elt_start_date_time"
                        , "status" : "src.status"
                        , "log_date_time" : "src.log_date_time"
                        , "orchestration_tool" : "src.orchestration_tool"
                        , "data_platform_version" : "src.data_platform_version"
                    
                    }
            ).execute()      
        
    def update_elt_log(self, master_run_id: str, table: str = 'elt_log'):
        status = 'Succeeded'

        elt_zone_log_df = DeltaTable.forPath(self.spark, self.elt_zone_log_table_path).toDF()
        elt_zone_log_errors_df = elt_zone_log_df.filter(f"elt_id == '{master_run_id}' and zone_status != 'Succeeded'")

        if (elt_zone_log_errors_df.count() > 0):
            status = 'Failed'

        elt_log_delta_table = DeltaTable.forPath(self.spark, self.elt_log_table_path)

        elt_log_delta_table.update(
            condition = f"master_run_id = '{master_run_id}'"
            , set = {
                    "elt_end_date_time" : lit(current_timestamp())
                    , "updated_date_time" : lit(current_timestamp())
                    , "status" : f"'{status}'"
            }
        )

    def update_status_for_elt_zone_log(self,
                                    zone_end_date_time: datetime,
                                    status: str,
                                    zone: str,
                                    elt_id: int,
                                    total_data_size: int,
                                    stage: str):
        
        elt_zone_log_table = DeltaTable.forPath(self.spark, self.elt_zone_log_table_path)

        elt_zone_log_table.update(
        condition = f"zone = '{zone}' and elt_id = '{elt_id}' and stage = '{stage}'",
        set = {
            "zone_end_date_time": expr(f"'{zone_end_date_time}'"),
            "zone_status": expr(f"'{status}'"),
            "total_data_size": expr(f"{total_data_size}")
        }
    )
         

    def insert_source_ingestion_log(self, log_df: DataFrame):
        cols_write_order = DeltaTable.forPath(self.spark, self.source_ingestion_log_table_path).toDF().columns
        raw_log_df = log_df.filter("zone == 'Raw'")
        curated_log_df = log_df.filter("zone == 'Curated'")

        if (raw_log_df.count() > 0):
            raw_source_ingestion_log_cols_list = [
                'run_id'
                , 'elt_id'
                , 'product_name'
                , 'feed_name'
                , 'source_system'
                , 'dataset_name'
                , 'metadata'
                , 'metadata.errors'
                , 'zone_start_date_time'
                , 'zone_end_date_time'
                , 'zone'
                , 'orchestration_tool'
                , 'metadata.executionDetails.status'
            ]

            raw_projected_df = raw_log_df.select(raw_source_ingestion_log_cols_list)
            raw_projected_df = (raw_projected_df
                                .selectExpr(
                                    "run_id as run_id"
                                    , "elt_id as elt_id"
                                    , "cast(zone_start_date_time as timestamp) as start_date_time"
                                    , "cast(zone_end_date_time as timestamp) as end_date_time"
                                    , "metadata as metadata"
                                    , "cast(metadata.dataRead as long) as data_read"
                                    , "cast(metadata.dataWritten as long) as data_written"
                                    , "cast(metadata.filesRead as int) as files_read"
                                    , "cast(metadata.filesWritten as int) as files_written"
                                    , "cast(metadata.throughput as double) as throughput"
                                    , "cast(metadata.copyDuration as int) as copy_duration"
                                    , "orchestration_tool as inserted_by"
                                    , "status[0] as status"
                                    , "product_name as product_name"
                                    , "feed_name as feed_name"
                                    , "source_system as source_system"
                                    , "dataset_name as dataset_name"
                                    , "zone as zone"
                                    , "cast(null as string) as modified_by"
                                )
                            )

            raw_projected_df = (raw_projected_df.withColumn("metadata", to_json(col("metadata"))))        
            raw_projected_df = (raw_projected_df.select(cols_write_order))
            delta_operations_handler(lambda: raw_projected_df.write.format("delta").mode("append").save(self.source_ingestion_log_table_path) )
            self.logger.info(f"Source Ingestion Log data was written for raw zone to : {self.lakehouse}.{self.schema}.{self.source_ingestion_log_table_name}")

        if (curated_log_df.count() > 0):
            curated_source_ingestion_log_cols_list = [
                'run_id'
                , 'elt_id'
                , 'product_name'
                , 'feed_name'
                , 'source_system'
                , 'dataset_name'
                , 'metadata'
                , 'metadata.runOutput.success'
                , 'metadata.runOutput.startTime'
                , 'metadata.runOutput.endTime'
                , 'zone'
                , 'orchestration_tool'
                , 'zone_start_date_time'
                , 'zone_end_date_time'
            ]

            curated_projected_df = curated_log_df.select(curated_source_ingestion_log_cols_list)
            curated_projected_df = (curated_projected_df
                                .selectExpr(
                                    "run_id as run_id"
                                    , "elt_id as elt_id"
                                    , "cast(metadata.runOutput.startTime as timestamp) as start_date_time"
                                    , "cast(metadata.runOutput.endTime as timestamp) as end_date_time"
                                    , "metadata as metadata"
                                    , "cast(null as long) as data_read"
                                    , "cast(null as long) as data_written"
                                    , "cast(null as int) as files_read"
                                    , "cast(null as int) as files_written"
                                    , "cast(null as double) as throughput"
                                    , "cast(null as int) as copy_duration"
                                    , "orchestration_tool as inserted_by"
                                    , "case when metadata.runOutput.success then True else False end as is_success"
                                    , "product_name as product_name"
                                    , "feed_name as feed_name"
                                    , "source_system as source_system"
                                    , "dataset_name as dataset_name"
                                    , "zone as zone"
                                    , "cast(null as string) as modified_by"
                                )
                            )
            
            curated_projected_df = (curated_projected_df.withColumn("metadata", to_json(col("metadata"))))            
            curated_projected_df = curated_projected_df.withColumn("status", expr("case when is_success then 'Succeeded' ELSE 'Failed' END"))
            curated_projected_df = (curated_projected_df.select(cols_write_order))          
            delta_operations_handler(lambda: curated_projected_df.write.format("delta").mode("append").save(self.source_ingestion_log_table_path) )
            self.logger.info(f"Source Ingestion Log data was written for curated zone to : {self.lakehouse}.{self.schema}.{self.source_ingestion_log_table_name}")

    def insert_elt_zone_log(self, log_df: DataFrame):
        cols_write_order = DeltaTable.forPath(self.spark, self.elt_zone_log_table_path).toDF().columns
        raw_log_df = log_df.filter("zone == 'Raw'")
        curated_log_df = log_df.filter("zone == 'Curated'")

        if (raw_log_df.count() > 0):
            raw_elt_zone_log_cols_list = [
                'run_id'
                , 'elt_id'
                , 'product_name'
                , 'feed_name'
                , 'metadata'
                , 'metadata.errors'
                , 'zone_start_date_time'
                , 'zone_end_date_time'
                , 'zone'
                , 'orchestration_tool'
                , 'metadata.executionDetails.status'
                , 'stage'
            ]
            raw_projected_df = raw_log_df.select(raw_elt_zone_log_cols_list)
            raw_projected_df = (raw_projected_df
                                .selectExpr(
                                    "run_id as run_id"
                                    , "elt_id as elt_id"
                                    , "product_name as product_name"
                                    , "feed_name as feed_name"
                                    , "zone as zone"
                                    , "stage as stage"
                                    , "cast(zone_start_date_time as timestamp) as zone_start_date_time"
                                    , "cast(zone_end_date_time as timestamp) as zone_end_date_time"
                                    , "status[0] as zone_status"
                                    , "cast(metadata.dataWritten as int) as total_data_size"
                                    , "cast(0 as int) as total_models_shared"
                                    , "cast(0 as int) as total_retry_count"
                                    , "cast(0 as int) as total_error_count"
                                    , "run_id as invocation_id"
                                )
                            )
            raw_projected_df = (raw_projected_df.select(cols_write_order))
            delta_operations_handler(lambda: raw_projected_df.write.format("delta").mode("append").save(self.elt_zone_log_table_path) )
            self.logger.info(f"ETL Zone Log data was written for raw zone to : {self.lakehouse}.{self.schema}.{self.elt_zone_log_table_name}")

        if (curated_log_df.count() > 0):
            curated_elt_zone_log_cols_list = [
                'run_id'
                , 'elt_id'
                , 'product_name'
                , 'feed_name'
                , 'zone'
                , 'stage'
                , 'metadata.runOutput.success'
                , 'metadata.runOutput.startTime'
                , 'metadata.runOutput.endTime'
                , 'metadata.runOutput.outputBytes'
                , 'zone_start_date_time'
                , 'zone_end_date_time'
                ]
            
            curated_projected_df = curated_log_df.select(curated_elt_zone_log_cols_list)
            curated_projected_df = (curated_projected_df.selectExpr(
                                    "run_id as run_id"
                                    , "elt_id as elt_id"
                                    , "product_name as product_name"
                                    , "feed_name as feed_name"
                                    , "zone as zone"
                                    , "stage as stage"                        
                                    , "cast(startTime as timestamp) as zone_start_date_time"
                                    , "cast(endTime as timestamp) as zone_end_date_time"
                                    , "success as is_success"
                                    , "cast(outputBytes as int) as total_data_size"
                                    , "cast(0 as int) as total_models_shared"
                                    , "cast(0 as int) as total_retry_count"
                                    , "cast(0 as int) as total_error_count"
                                    , "run_id as invocation_id"
                                ))
            curated_projected_df = curated_projected_df.withColumn("zone_status", expr("case when is_success then 'Succeeded' ELSE 'Failed' END"))
            curated_projected_df = (curated_projected_df.select(cols_write_order))
            delta_operations_handler(lambda: curated_projected_df.write.format("delta").mode("append").save(self.elt_zone_log_table_path) )
            self.logger.info(f"ETL Zone Log data was written for curated zone to : {self.lakehouse}.{self.schema}.{self.elt_zone_log_table_name}")

    def get_zone_log_data(self, elt_id: str) -> DataFrame:
        _df = DeltaTable.forPath(self.spark, self.elt_zone_log_table_path).toDF()
        _df = _df.filter(f"elt_id == '{elt_id}'")
        return _df        
    