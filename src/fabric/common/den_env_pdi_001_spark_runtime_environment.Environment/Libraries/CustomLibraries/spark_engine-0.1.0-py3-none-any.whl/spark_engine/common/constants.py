OBS_LAKEHOUSE_NAME = "den_lhw_pdi_001_observability"
OBS_LAKEHOUSE_SCHEMA = "audit"
SOURCE_INGEST_LOG_TABLE = "source_ingestion_log"
QUARANTINE_LOG_TABLE = "quarantine_log"