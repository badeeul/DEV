from enum import Enum

class SourceDataTypes(str, Enum):
    JSON = "json"
    CSV = "csv"
    TXT = "txt"
    PARQUET = "parquet"

    @classmethod
    def _missing_(cls, value):
        for member in cls:
            if member.value == value.lower():
                return member
            
        raise ValueError(
            f"Invalid source data type. Must be one of {', '.join([_.value for _ in cls])}"
        )