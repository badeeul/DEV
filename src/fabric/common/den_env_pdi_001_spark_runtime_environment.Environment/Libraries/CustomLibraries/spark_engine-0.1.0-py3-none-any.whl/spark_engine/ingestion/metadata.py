from typing import Dict, List, Optional
from datetime import datetime, timezone
from pyspark.sql.functions import lit, concat_ws, substring, sha2, to_timestamp, col
from pyspark.sql.dataframe import DataFrame, Column


class Metadata:
    meta_column_prefix: str
    batch_time: datetime
    file_path: str
    data: DataFrame

    def __init__(self, config: Dict, columns: List[str]) -> None:
        self.meta_column_prefix = config.get("meta_column_prefix", "dl_")
        self.batch_time = config.get("batch_time", datetime.now(timezone.utc))
        self.elt_id = config.get("elt_id", "0")
        self.run_id = config.get("run_id", "0")
        self.columns = columns

        self.metadata_columns = self.generate_ingest_metadata()

    def generate_ingest_metadata(self) -> Dict[str, Column]:
        return {
            self.meta_column_prefix
            + "rowhash": sha2(concat_ws("||", *self.columns), 256),
            self.meta_column_prefix + "partitionkey": substring("dl_rowhash", 0, 1),
            self.meta_column_prefix + "iscurrent": lit(True),
            self.meta_column_prefix + "recordstartdateutc": lit(self.batch_time).cast("timestamp"),
            self.meta_column_prefix
            + "recordenddateutc": to_timestamp(lit(None), "yyyy-MM-ddTHH:mm:ss"),
            self.meta_column_prefix + "createddateutc": lit(self.batch_time).cast("timestamp"),
            self.meta_column_prefix + "lastmodifiedutc": lit(self.batch_time).cast("timestamp"),
            self.meta_column_prefix
            + "sourcefilepath": col(
                self.meta_column_prefix + "sourcefilepath"
                if self.meta_column_prefix + "sourcefilepath" in self.columns
                else "_metadata.file_path"
            ),
            self.meta_column_prefix
            + "sourcefilename": col(
                self.meta_column_prefix + "sourcefilename"
                if self.meta_column_prefix + "sourcefilename" in self.columns
                else "_metadata.file_name"
            ),
             self.meta_column_prefix + "eltid": lit(self.elt_id).cast("string"),
             self.meta_column_prefix + "runid": lit(self.run_id).cast("string"),
             self.meta_column_prefix + "isdeleted": lit(False),
        }

    def get_metadata_column_names(self) -> List[str]:
        return list(self.metadata_columns.keys())

    def add_ingest_metadata_columns(
        self, df: DataFrame, metadata_columns: Optional[List[str]] = None
    ) -> DataFrame:
        if metadata_columns is None:
            metadata_columns = self.get_metadata_column_names()

        return df.withColumns(
            {
                column: self.metadata_columns[column]
                for column in metadata_columns
                if column not in df.columns
            }
        )
