import msal
import requests
import fsspec
import base64 as b64
import os
from typing import List, Optional
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from notebookutils import credentials

def get_access_token(client_id, client_secret, tenant_id):
    authority = f"https://login.microsoftonline.com/{tenant_id}"
    app = msal.ConfidentialClientApplication(
        client_id,
        authority=authority,
        client_credential=client_secret
    )
    scope = ["https://graph.microsoft.com/.default"]
    result = app.acquire_token_for_client(scopes=scope)
    return result['access_token']

def get_secret(secret_name, key_vault_name):
    key_vault_uri = f"https://{key_vault_name}.vault.azure.net"
    credential = DefaultAzureCredential()
    client = SecretClient(vault_url=key_vault_uri, credential=credential)
    secret = client.get_secret(secret_name)
    return secret 

def get_secret_notebookutils(secret_name, key_vault_name):
    key_vault_uri = f"https://{key_vault_name}.vault.azure.net"
    secret = credentials.getSecret(key_vault_uri, secret_name)
    return secret

def build_recipients(to_email):
    return [
        {
            "emailAddress": {
                "address": recipient
            }
        }
        for recipient in to_email.split(";")
    ]


def build_attachments(attachments:List):
    storage_options = {
        "account_name": "onelake",
        "account_host": "onelake.dfs.fabric.microsoft.com",
    }
    onelake_fs = fsspec.filesystem("abfss", **storage_options)

    return [
        {
            "@odata.type": "#microsoft.graph.fileAttachment",
            "name": os.path.basename(attachment),
            "contentBytes": b64.b64encode(onelake_fs.open(attachment, 'rb').read())
        }
        for attachment in attachments
    ]

def send_email(subject:str, body:str, to_email:str, from_account:str, key_vault_name:str, cc_email:Optional[str]=None, bcc_email:Optional[str]=None, attachments:Optional[List]=None):
    '''
    Parameters
    ----------
    :subject: str `Subject of the email.
    :body: str `Body of the email in html format.
    :to_email: str `Recipients of the email. Multiple recipients can be separated by a semicolon (;)
    :from_account: str `Sender of the email.
    :key_vault_name: str `Name of the key vault that contains the secret required for the Service Principal.
    :cc_email: str `CC Recipients of the email. Multiple recipients can be separated by a semicolon (;)
    :bcc_email: str `BCC Recipients of the email. Multiple recipients can be separated by a semicolon (;)
    :attachments: List `List of attachments full abfss paths

    '''
    client_id = get_secret_notebookutils("spn-gdap-dnafluidity-noreply-email-clientid", key_vault_name)
    client_secret = get_secret_notebookutils("spn-gdap-dnafluidity-noreply-email-secret", key_vault_name)
    tenant_id = get_secret_notebookutils("BHGuardTenantId", key_vault_name)
    
    access_token = get_access_token(client_id, client_secret, tenant_id)
    endpoint = f"https://graph.microsoft.com/v1.0/users/{from_account}/sendMail"
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }
    email_msg = {
        "message": {
            "subject": subject,
            "body": {
                "contentType": "HTML",
                "content": body
            },
            "toRecipients": build_recipients(to_email)
        }
    }

    if cc_email:
        email_msg["message"]["ccRecipients"] = build_recipients(cc_email)

    if bcc_email:
        email_msg["message"]["bccRecipients"] = build_recipients(bcc_email)

    if attachments:
        email_msg["message"]["attachments"] = build_attachments(attachments)


    response = requests.post(endpoint, headers=headers, json=email_msg)
    if response.status_code == 202:
        print('Mail Sent')
    else:
        print(f'Error: {response.status_code}')
        print(response.json())
