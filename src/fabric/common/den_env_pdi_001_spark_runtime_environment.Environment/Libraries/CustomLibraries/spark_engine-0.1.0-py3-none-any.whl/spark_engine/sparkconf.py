import sys
from pyspark.sql import SparkSession
from pyspark.conf import SparkConf

# Spark session builder
# os.environ['LOG_FILE_PATH'] = os.path.join('..', 'log', 'SparkLighter.log')
conf = SparkConf()
conf.set(
    "spark.lighter.client.plugin", "org.apache.spark.lighter.DefaultLighterClientPlugin"
)
conf.set("spark.sql.catalogImplementation", "lighter")
conf.set(
    "spark.lighter.sessionState.implementation",
    "org.apache.spark.sql.lighter.client.SparkLighterSessionStateBuilder",
)
conf.set(
    "spark.lighter.externalCatalog.implementation",
    "org.apache.spark.sql.lighter.client.ConnectCatalogClient",
)
conf.set("spark.sql.exentensions", "io.delta.sql.DeltaSparkSessionExtension")
conf.set(
    "spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog"
)
conf.set("spark.sql.legacy.parquet.int96RebaseModeInRead", "CORRECTED")
conf.set("spark.sql.legacy.parquet.int96RebaseModeInWrite", "CORRECTED")
conf.set("spark.sql.legacy.parquet.datetimeRebaseModeInRead", "CORRECTED")
conf.set("spark.sql.legacy.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark = SparkSession.builder.appName("sparkengine").config(conf=conf).getOrCreate()

spark_context = spark.sparkContext
spark_context.setLogLevel("ERROR")
