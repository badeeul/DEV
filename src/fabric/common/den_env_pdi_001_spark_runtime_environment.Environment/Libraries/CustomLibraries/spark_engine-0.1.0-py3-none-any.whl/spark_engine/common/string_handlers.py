import re
import itertools


def remove_vowels_from_string(source_string: str) -> str:
    """
    Strips out all vowels from a string.

    Parameters:
        source_string   : str, mandatory

    Output:
        Input string without vowels
    """
    vowels = {"a", "e", "i", "o", "u", "A", "E", "I", "O", "U"}
    return "".join([l for l in source_string if l not in vowels])


def strip_string(
    string_to_clean: str,
    replace_with: str = "",
    to_lower: bool = False,
    remove_vowels: bool = False,
    trim_length: int = 0,
    dedupe: bool = False,
) -> str:
    """
    Removes any non-alphanumeric characters from a
    string, with exception of underscore.
    Optionally replaces characters with supplied character.
    Optionally changes string to lower case.
    Optionally removes vowels from string.
    Optionally returns only left(n) characters from string.
    Optionally dedupes the string for consecutively duplicated letters.

    Paremeters  :
        string_to_clean : str, mandatory
        replace_with    : str, optional (default is "")
        to_lower        : boolean, optional (default is False)
        remove_vowels   : boolean, optional (default is False)
        trim_length     : int, optional
        dedupe          : boolean, optional (default is False)

    Output      :
        Returns cleaned string, optionally with vowels removed
        and/or trimmed to specified length.
    """
    if string_to_clean:
        out_string = re.sub(r"\W", replace_with, string_to_clean)

        if to_lower:
            out_string = out_string.lower()

        if remove_vowels:
            out_string = remove_vowels_from_string(out_string)

        if trim_length > 0:
            out_string = out_string[:trim_length]

        if dedupe:
            out_string = "".join(ch for ch, _ in itertools.groupby(out_string))

    else:
        out_string = string_to_clean

    return out_string
