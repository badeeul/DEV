from enum import Enum

class QuarantineLoadType(Enum):
    MERGE = "merge"
    APPEND = "append"
    OVERWRITE = "overwrite"
